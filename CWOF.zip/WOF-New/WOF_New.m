classdef WOF_New < ALGORITHM
% <multi> <real/integer> <large/none>
% Weighted optimization framework
% gamma         --- 4    --- Number of groups. Default = 4 
% groups        --- 2    --- Grouping method, 1 = linear, 2 = ordered, 3 =  random. Default = ordered 
% psi           --- 4   --- Transformation function, 1 = Multiplication, 2 = P-Value, 3 = Interval.4=power, Default = Interval
% q             ---      --- The number of chosen solutions to do weight optimisation. If no value is specified, the default value is M+1
% delta         --- 0.5  --- The fraction of function evaluations to use for the alternating weight-optimisation phase. Default = 0.5
% optimiser     --- 1    --- Internal optimisation algorithm. 1 = SMPSO, 2 = MOEAD, 3 = NSGAII, 4 = NSGAIII. Default = NSGAIII. Only used if the randomOptimisers parameter is set to 0.

    methods
        function main(Algorithm,Problem) 
            %% Set the default parameters
            [gamma,groups,psi,q,delta,optimiser] = Algorithm.ParameterSet(4,2,4,Problem.M+1,0.5,1);
            WOF_New_WeightIndividual.Current(Problem); 
            
            %% Generate random population 
            Population = Problem.Initialization();
            Algorithm.NotTerminated(Population);
            %% Start the alternating optimisation
            % The size of the population of weight-Individuals 
            transformedProblemPopulationSize = 10; 
            if optimiser ==4 || optimiser ==2
                [uniW,Problem.N] = UniformPoint(Problem.N,Problem.M);  
            end      
            while Problem.FE < delta*Problem.maxFE             
               [t1,t2]=update_t(Problem.FE,delta*Problem.maxFE);               
                Population = WOFfillPopulation(Population, Problem);
                if  optimiser == 4
                    Population = WOF_New_optimiseByNSGAIII(Problem, Population, uniW, t1, false);
                elseif  optimiser == 3
                    Population = WOF_New_optimiseByNSGAII(Problem, Population, t1, false);
                elseif  optimiser == 2
                    Population = WOF_New_optimiseByMOEAD(Problem, Population, uniW, t1, false);
                else 
                    Population = WOF_New_optimiseBySMPSO(Problem, Population, t1, false);
                end

                Algorithm.NotTerminated(Population); 
                
                % Selection of xPrime
                xPrimeList = WOF_New_selectxPrimes(Population, q); 
                WList   = [];

                % do for each xPrime
                for c = 1:size(xPrimeList,2)
                    xPrime = xPrimeList(c);

                    % create variable groups 
                    [G,gamma] = WOF_New_createGroups(Problem,gamma,xPrime,groups);                                   

                    % a dummy object is needed to simulate the global
                    % class. Its necessary to include this method into the
                    % Platemo framework. 
                    GlobalDummy = WOFcreateGlobalDummy(gamma, xPrime, G, Problem, transformedProblemPopulationSize, psi,optimiser);                  

                    % Create initial population for the transformed problem
                    WeightPopulation = WOFcreateInitialWeightPopulation(GlobalDummy.N, gamma, GlobalDummy);
                    
                    % Optimise the transformed problem 
                    if optimiser == 4
                        WeightPopulation = WOF_New_optimiseByNSGAIII(GlobalDummy, WeightPopulation, GlobalDummy.uniW, t2-transformedProblemPopulationSize, true);
                    elseif  optimiser == 3
                        WeightPopulation    = WOF_New_optimiseByNSGAII(GlobalDummy, WeightPopulation, t2-transformedProblemPopulationSize, true);
                    elseif  optimiser == 2
                        WeightPopulation    = WOF_New_optimiseByMOEAD(GlobalDummy, WeightPopulation, GlobalDummy.uniW, t2-transformedProblemPopulationSize, true);
                    else 
                        WeightPopulation    = WOF_New_optimiseBySMPSO(GlobalDummy, WeightPopulation, t2-transformedProblemPopulationSize, true);
                    end

                    % Extract the population 
                    W                   = WOFextractPopulation(WeightPopulation, Problem, Population, G, psi, xPrime, q);
                    WList               = [WList,W];  
                end

                % Join populations. Duplicate solution (e.g. found in different optimisation steps with different xPrimes) need to be removed. 
                Population          = WOFeliminateDuplicates([Population,WList]);
                Population          = WOFfillPopulation(Population, Problem);

                % Environmental Selection
                [Population,~,~]    = WOF_New_EnvironmentalSelection(Population,Problem.N);            
                
                Algorithm.NotTerminated(Population); 
            end                                       
                 
                optimiser=4;
                if optimiser == 2 || optimiser ==4
                    [uniW,Problem.N] = UniformPoint(Problem.N,Problem.M);
                end  
                t1=1000; 
                while Algorithm.NotTerminated(Population)                                      
                    Population = WOFfillPopulation(Population, Problem); 
                                                    
                    if  optimiser == 4
                        Population = WOF_optimiseByNSGAIII(Problem, Population, uniW, t1, false);
                    elseif  optimiser == 3
                        Population = WOF_optimiseByNSGAII(Problem, Population, t1, false);
                    elseif  optimiser == 2
                        Population = WOF_optimiseByMOEAD(Problem, Population, uniW, t1, false);
                    else
                        Population = WOF_optimiseBySMPSO(Problem, Population, t1, false);
                    end
                end 
            end
        end
end

function GlobalDummy = WOFcreateGlobalDummy(gamma, xPrime, G, Global, populationSize, psi,optimiser)
    % Creates a dummy object. Needed to simulate the global class.
    % Its necessary to include this method into the Platemo framework. 
    GlobalDummy = {};
    GlobalDummy.lower       = zeros(1,gamma);
    GlobalDummy.upper       = ones(1,gamma).*2.0;
    if optimiser == 2 || optimiser == 4
        [uniW,GlobalDummy.N]    = UniformPoint(populationSize,Global.M);
        GlobalDummy.uniW        = uniW;
    else
        GlobalDummy.N           = populationSize;
    end
    GlobalDummy.xPrime      = xPrime;
    GlobalDummy.G           = G;
    GlobalDummy.psi         = psi;
    GlobalDummy.xPrimelower = Global.lower;
    GlobalDummy.xPrimeupper = Global.upper;
    GlobalDummy.isDummy     = true;
    GlobalDummy.Global      = Global;
end

function Population = WOFeliminateDuplicates(input)
    % Eliminates duplicates in the population
    [~,ia,~] = unique(input.objs,'rows');
    Population = input(ia);
end

function Population = WOFfillPopulation(input, Global)
    % Fills the population with mutations in case its smaller than Global.N
    Population = input;
    theCurrentPopulationSize = size(input,2);
    if theCurrentPopulationSize < Global.N
        amountToFill    = Global.N-theCurrentPopulationSize;
        FrontNo         = NDSort(input.objs,inf);
        CrowdDis        = CrowdingDistance(input.objs,FrontNo);
        MatingPool      = TournamentSelection(2,amountToFill+1,FrontNo,-CrowdDis);
        Offspring       = OperatorGA(Global,input(MatingPool));
        Population      = [Population,Offspring(1:amountToFill)];
    end
end

function WeightPopulation = WOFcreateInitialWeightPopulation(N, gamma, GlobalDummy)
    %creates an initial population for the transformed problem
    decs = rand(N,gamma).*2.0; 
    WeightPopulation = [];
    for i = 1:N
        solution = WOF_New_WeightIndividual(decs(i,:),GlobalDummy);
        WeightPopulation = [WeightPopulation, solution];
    end
end

function W = WOFextractPopulation(WeightPopulation, Problem, Population, G, psi, xPrime, q)
    % Extracts a population of individuals for the original problem based
    % on the optimised weights. 
    % First a selection of M+1 Weight-Individuals is selected and apllied
    % to the whole population each. 
    % Second all Weight-Individuals are applied to the chosen xPrime
    % solution, since they are optimised for it.   
    weightIndividualList = WOF_New_selectxPrimes(WeightPopulation, q);
    calc = size(weightIndividualList,2)*size(Population,2);

    PopDec1 = ones(calc,Problem.D);
    count = 1;
    for wi = 1:size(weightIndividualList,2)
        weightIndividual = weightIndividualList(wi);
        weightVars = weightIndividual.dec;
        
        for i = 1:size(Population,2)
            individualVars = Population(i).dec;
            
            x = WOF_New_transformationFunctionMatrixForm(individualVars,weightVars(G),Problem.upper,Problem.lower, psi);

            PopDec1(count,:) = x;
            count = count + 1;
        end
        
    end
    
    W1 = Problem.Evaluation(PopDec1);
    PopDec2 = [];
    for wi = 1:size(WeightPopulation,2) 
        weightIndividual = WeightPopulation(wi);
        weightVars = weightIndividual.dec;
        
            individualVars = xPrime.dec;
            x = 1:Problem.D;
            for j = 1:Problem.D
                x(j) = WOF_New_transformationFunction(individualVars(j),weightVars(G(j)),Problem.upper(j),Problem.lower(j), psi);   
            end
            PopDec2 = [PopDec2;x]; 
    end
    W2 = Problem.Evaluation(PopDec2);
    
    W = [W1,W2];
end


function [t1, t2] = update_t(FE, maxFE)
    R = FE / maxFE;
    
    k1 = 10;
    k2 = 12;

    t1 = 1000 + 500 * (1 / (1 + exp(-k1 * (R - 0.5))));
    t2 = 800 - 300 * (1 / (1 + exp(-k2 * (R - 0.4))));
end



