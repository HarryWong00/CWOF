function weightIndList = WOF_New_selectxPrimes(input,amount)
%Bi-clustering
%input：种群
%amount：解q的数量
%method:选择的方法   
    pop=input;
    nCluster=amount;                           
    element = pop(1); 
    if numel(fieldnames(element)) == 4                
        decisionVars=pop.decs;
        [row, ~] = size(decisionVars);                   
        if row <= nCluster 
            weightIndList= pop;                     
        else                 
            if ~isreal(decisionVars)
                decisionVars = real(decisionVars);
            end
            Z1 = min(decisionVars, [], 1);
            Z2 = max(decisionVars, [], 1);
            epsilon = 1e-5; 
            range = Z2 - Z1;
            range(range == 0) = epsilon;
            ZZZ = (decisionVars - Z1) ./ repmat(range, length(pop), 1);

             Z=linkage(ZZZ,'ward');
             cluster_first=cluster(Z,"maxclust",nCluster);
             centroids = zeros(nCluster,size(ZZZ, 2));
             for i = 1:nCluster 
                cluster_points = ZZZ(cluster_first == i, :);
                centroids(i, :) = mean(cluster_points,1);
             end                                     
         
                newMaxIter = 300;            
                opts = statset('MaxIter', newMaxIter);
                [idx, clusterCenter] = kmeans( ZZZ, nCluster, 'Start',  centroids, 'Options', opts,'Distance','sqeuclidean');
                selectedIndices = zeros( nCluster, 1);
                for k = 1:nCluster
                    clusterIndices = find(idx == k);
                    distances = sqrt(sum(( ZZZ(clusterIndices, :) - clusterCenter(k, :)).^2, 2));
                    [~, minIndex] = min(distances);
                    selectedIndices(k) = clusterIndices(minIndex);
                end
                selectedIndividuals = pop(selectedIndices);               
                weightIndList= selectedIndividuals;
        end
    else  
        FrontNo    = NDSort(input.objs,inf);
        CrowdDis   = CrowdingDistance(input.objs,FrontNo);
        weightIndList = input(TournamentSelection(2,amount,FrontNo,-CrowdDis));     
    end         
end
       

