function weightIndList = WOF_New3_selectxPrimes(input,amount, method)
%input：种群
%amount：枢轴解q的数量
%method:选择的方法
    inputSize = size(input,2);
    switch method 
        case 1 %largest Crowding Distance from first front 
            inFrontNo    = NDSort(input.objs,inf);
            weightIndList = [];
            i = 1;
            if inputSize < amount
                weightIndList = input;
            else
                while size(weightIndList,2) < amount 
                    left = amount - size(weightIndList,2);
                    theFront = inFrontNo == i;
                    newPop = input(theFront);
                    FrontNo    = NDSort(newPop.objs,inf);
                    CrowdDis   = CrowdingDistance(newPop.objs,FrontNo); 
                    [~,I] = sort(CrowdDis,'descend');
                    until=min(left,size(newPop,2));
                    weightIndList = [weightIndList,newPop(I(1:until))];
                    i=i+1;
                end
            end
        case 2 %tournament selection by front and CD
            FrontNo    = NDSort(input.objs,inf);
            CrowdDis   = CrowdingDistance(input.objs,FrontNo);
            weightIndList = input(TournamentSelection(2,amount,FrontNo,-CrowdDis));
        case 3 % first m+1 by reference lines + fill with random
            objValues = input.objs;
            m = size(objValues,2);
            weightIndList = [];
            for i = 1:m
                vec = zeros(1,m);
                vec(1,i) = 1;
                angles = pdist2(vec,real(objValues),'cosine'); 
                [minAngle,minIndex] = min(angles);
                weightIndList = [weightIndList,input(minIndex)];
            end
            if size(weightIndList,2) < amount
                vec = ones(1,m);
                angles = pdist2(vec,real(objValues),'cosine');
                [minAngle,minIndex] = min(angles);
                weightIndList = [weightIndList,input(minIndex)];
            end
            while size(weightIndList,2) < amount
                ind = input(randi([1 inputSize],1,1));
                weightIndList = [weightIndList,ind];
            end
         case 4 
                pop=input;
                nCluster=amount;                           
                element = pop(1);               
                if numel(fieldnames(element)) == 4                
                    decisionVars=pop.decs;
                    [row, ~] = size(decisionVars);                     
                    if row < nCluster 
                        weightIndList= pop;
                    else
                        newMaxIter = 200;  
                        opts = statset('MaxIter', newMaxIter);

                        [idx, clusterCenter] = kmeans(decisionVars, nCluster, 'Start', 'plus', 'Options', opts);
                        selectedIndices = zeros( nCluster, 1); 
                        for i = 1: nCluster
                            clusterIndices = find(idx == i);
                            distances = sqrt(sum((decisionVars(clusterIndices, :) - clusterCenter(i, :)).^2, 2));
                            [~, minIndex] = min(distances);
                            selectedIndices(i) = clusterIndices(minIndex);
                            
                        end
                        selectedIndividuals = pop(selectedIndices);               
                        weightIndList= selectedIndividuals;
                    end
                else                
                    indArray = pop(1).ind;
                    indStructures = repmat(indArray, 1, size(pop,2));
                    for i = 2:size(pop,2)                    
                       currentStructure = pop(i).ind;                    
                       indStructures(i) = currentStructure;
                    end                   
                    decisionVars=indStructures.decs;
                    [row, ~] = size(decisionVars);                   
                    if row < nCluster 
                       weightIndList= pop; 
                    else
                        newMaxIter = 200;                        
                        opts = statset('MaxIter', newMaxIter);
                        [idx, clusterCenter] = kmeans(decisionVars, nCluster, 'Start', 'plus', 'Options', opts);                    
                        selectedIndices = zeros( nCluster, 1);
                        for i = 1: nCluster
                            clusterIndices = find(idx == i);
                             distances = sqrt(sum((decisionVars(clusterIndices, :) - clusterCenter(i, :)).^2, 2));
                            [~, minIndex] = min(distances);
                            selectedIndices(i) = clusterIndices(minIndex);                                                    
                        end
                        selectedIndividuals = pop(selectedIndices);               
                        weightIndList= selectedIndividuals;
                    end
                end

        case 5 %Bi-cluster
                pop=input;
                nCluster=amount;                           
                element = pop(1); 
                if numel(fieldnames(element)) == 4                
                    decisionVars=pop.decs;
                    [row, ~] = size(decisionVars);                   
                    if row < nCluster 
                        weightIndList= pop;                     
                    else
                                            % 检查 decisionVars 是否为实数
                    if ~isreal(decisionVars)
                        warning('输入变量包含非实数部分，将转换为实数部分。');
                        decisionVars = real(decisionVars); % 转换为实数部分
                    end
                        Z=linkage(decisionVars,'ward');
                        cluster_first=cluster(Z,"maxclust",nCluster);
                        centroids = zeros(nCluster,size(decisionVars, 2));
                        for i = 1:nCluster
                            cluster_points = decisionVars(cluster_first == i, :);
                            centroids(i, :) = mean(cluster_points);
                        end
                        newMaxIter = 100;
                        opts = statset('MaxIter', newMaxIter);
                        [idx, clusterCenter] = kmeans(decisionVars, nCluster, 'Start', centroids, 'Options', opts,'Distance','sqeuclidean');
                        selectedIndices = zeros( nCluster, 1);
                        for i = 1: nCluster
                            clusterIndices = find(idx == i);
                            distances = sqrt(sum((decisionVars(clusterIndices, :) - clusterCenter(i, :)).^2, 2));
                            [~, minIndex] = min(distances);
                            selectedIndices(i) = clusterIndices(minIndex);
                            
                        end                   
                        selectedIndividuals = pop(selectedIndices);               
                        weightIndList= selectedIndividuals;
                    end
                else  
                    FrontNo    = NDSort(input.objs,inf);
                    CrowdDis   = CrowdingDistance(input.objs,FrontNo);
                    weightIndList = input(TournamentSelection(2,amount,FrontNo,-CrowdDis));     
                end         
     end
       
end
