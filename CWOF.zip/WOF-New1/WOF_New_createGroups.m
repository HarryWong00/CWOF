function [outIndexList,numberOfGroups] = WOF_New_createGroups(Problem,numberOfGroups,xPrime,method)
    
    switch method
        case 1 %linear grouping
            varsPerGroup = floor(Problem.D/numberOfGroups);
            outIndexList = [];
            for i = 1:numberOfGroups-1
               outIndexList = [outIndexList, ones(1,varsPerGroup).*i];
            end
            outIndexList = [outIndexList, ones(1,Problem.D-size(outIndexList,2)).*numberOfGroups];
        case 2 %orderByValueGrouping
            varsPerGroup = floor(Problem.D/numberOfGroups);
            vars = xPrime.dec;
            [~,I] = sort(vars);
            outIndexList = ones(1,Problem.D);
            for i = 1:numberOfGroups-1
               outIndexList(I(((i-1)*varsPerGroup)+1:i*varsPerGroup)) = i;
            end
            outIndexList(I(((numberOfGroups-1)*varsPerGroup)+1:end)) = numberOfGroups;
        case 3 %random Grouping
            varsPerGroup = floor(Problem.D/numberOfGroups);
            outIndexList = [];
            for i = 1:numberOfGroups-1
               outIndexList = [outIndexList, ones(1,varsPerGroup).*i];
            end
            outIndexList = [outIndexList, ones(1,Problem.D-size(outIndexList,2)).*numberOfGroups];
            outIndexList = outIndexList(randperm(length(outIndexList)));
        case 4 %up or down groups 分为上下2个组
            outIndexList = ones(1,Problem.D);
            xPrimeVars = xPrime.decs;
            xPrimeObjs = xPrime.objs;
            for i = 1 : Problem.D
                newSolVars = xPrime.decs;
                newSolVars(i) = xPrimeVars(i)*1.05;
                newSol = Problem.Evaluation(newSolVars);
                newSolObjs = newSol.objs;
                if newSolObjs(1) < xPrimeObjs(1)
                    outIndexList(i) = 2;
                end
            end
            numberOfGroups = 2;
        case 5 %diff groups
            outIndexList = zeros(1,Problem.D);%初始化分组索引为0
            vars = xPrime.dec;
           % group_size = floor(vars /numberOfGroups); % 计算每组的大小，假设要将决策变量均匀分为 4 组
            diff_vars=diff(vars);%计算决策变量之间的差分
            
            % 计算多个分组阈值
            thresholds = zeros(1, numberOfGroups - 1);
            for i = 1:numberOfGroups-1
                thresholds(i) = prctile(abs(diff_vars), i * 100 / numberOfGroups);
            end
            for i = 1:Problem.D-1               
                for j = 1:numberOfGroups-1
                    if abs(diff_vars(i)) <= thresholds(j)
                        outIndexList(i+1) = j;
                        break; % 找到匹配的分组索引后跳出循环
                    end
                end
            end
           outIndexList=outIndexList+1;           

         
                      

    end
end

                