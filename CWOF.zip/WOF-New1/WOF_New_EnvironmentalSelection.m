function [Population,FrontNo,CrowdDis] = WOF_New_EnvironmentalSelection(Population,N)
% The environmental selection of NSGA-II that is used inside WOF.
% This function is mostly identical to the original
% EnvironmentalSelection function from the NSGA-II algorithm. 


    
    %% Non-dominated sorting
    [FrontNo,MaxFNo] = NDSort(Population.objs,N);
    Next = false(1,length(FrontNo));
    Next(FrontNo<MaxFNo) = true;%前两个前沿的个体认为是好的
    
    %% Calculate the crowding distance of each solution
    CrowdDis = CrowdingDistance(Population.objs,FrontNo);
    
    %% Select the solutions in the last front based on their crowding distances
    Last     = find(FrontNo==MaxFNo);%在第三个前沿根据拥挤距离进行选择，如果前两个前沿中的解不够
    [~,Rank] = sort(CrowdDis(Last),'descend');
    Popsize = min(N,size(Population,2));
    Next(Last(Rank(1:Popsize-sum(Next)))) = true;
    
    %% Population for next generation
    Population = Population(Next);
    FrontNo    = FrontNo(Next);
    CrowdDis   = CrowdDis(Next);
end